<?php

include_once(__DIR__.DIRECTORY_SEPARATOR.'api'.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'Auth.php');
$auth = Auth::fromConfig();
$auth->basicAuth();
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>DB Setter</title>
</head>
<body>
<div class="row">
    <div class="mb-6">
        <form action="" method="POST" id="frmQuery">
            <fieldset>
                <legend> Database</legend>
                <div class="row">
                    <div class="mb-3">
                        <label for="companyIds" class="form-label">Database</label>
                        <select class="form-control" id="companyIds" placeholder="all databases" multiple required name="companyIds[]">
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="query" class="form-label">Query</label>
                        <textarea class="form-control" id="query"  name="query" required rows="6"></textarea>
                    </div>
                    <input type="hidden" id="secret" value="<?php echo $auth->getToken();?>" />
                    <button type="submit" id="form-submit" class="btn btn-success btn-lg pull-right ">Enviar</button>
                </div>
            </fieldset>
        </form>
        <div class="mb-3" style="display: none;" id="msg">
            <h1>Respuesta</h1>
            <dl></dl>
        </div>
    </div>
</div>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"
        integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"
        integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k"
        crossorigin="anonymous"></script>
<script src="./js/lib.js"></script>
</body>
</html>