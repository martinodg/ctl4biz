#Gestor de querys sobre bases multiples 
##instalacion 
* Copiar config.ini.exmaple a config.ini 
* Definir los datos de la base  , usuario y password en el archivo config.ini
##Forma de uso . 
* Seleccionar la/s tablas en la/s que se desea ejecutar el codigo SQL
* Escribir el codigo SQL en el campo de texto 
* Precionar enviar 
* Se mostrara el resultado de las distintas ajecciones en el campo resultado 
