-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: database
-- Generation Time: Apr 26, 2019 at 11:06 AM
-- Server version: 10.3.14-MariaDB-1:10.3.14+maria~bionic
-- PHP Version: 7.2.14

SET SQL_MODE = "";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emoonDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `albalinea`
--

CREATE TABLE `albalinea` (
  `codalbaran` int(11) NOT NULL DEFAULT 0,
  `numlinea` int(4) NOT NULL,
  `codfamilia` int(3) DEFAULT NULL,
  `codigo` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `cantidad` float NOT NULL DEFAULT 0,
  `precio` float NOT NULL DEFAULT 0,
  `importe` float NOT NULL DEFAULT 0,
  `dcto` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `albalineap`
--

CREATE TABLE `albalineap` (
  `codalbaran` varchar(20) NOT NULL DEFAULT '0',
  `codproveedor` int(5) NOT NULL DEFAULT 0,
  `numlinea` int(4) NOT NULL,
  `codfamilia` int(3) DEFAULT NULL,
  `codigo` varchar(15) DEFAULT NULL,
  `cantidad` float NOT NULL DEFAULT 0,
  `precio` float NOT NULL DEFAULT 0,
  `importe` float NOT NULL DEFAULT 0,
  `dcto` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `albalineap`
--

INSERT INTO `albalineap` (`codalbaran`, `codproveedor`, `numlinea`, `codfamilia`, `codigo`, `cantidad`, `precio`, `importe`, `dcto`) VALUES
('2', 2, 1, 1, '1', 1000, 10, 10000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `albalineaptmp`
--

CREATE TABLE `albalineaptmp` (
  `codalbaran` int(11) NOT NULL DEFAULT 0,
  `numlinea` int(4) NOT NULL,
  `codfamilia` int(3) DEFAULT NULL,
  `codigo` varchar(15) DEFAULT NULL,
  `cantidad` float NOT NULL DEFAULT 0,
  `precio` float NOT NULL DEFAULT 0,
  `importe` float NOT NULL DEFAULT 0,
  `dcto` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `albalineaptmp`
--

INSERT INTO `albalineaptmp` (`codalbaran`, `numlinea`, `codfamilia`, `codigo`, `cantidad`, `precio`, `importe`, `dcto`) VALUES
(0, 1, 1, '1', 1000, 10, 10000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `albalineatmp`
--

CREATE TABLE `albalineatmp` (
  `codalbaran` int(11) NOT NULL DEFAULT 0,
  `numlinea` int(4) NOT NULL,
  `codfamilia` int(3) DEFAULT NULL,
  `codigo` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
  `cantidad` float NOT NULL DEFAULT 0,
  `precio` float NOT NULL DEFAULT 0,
  `importe` float NOT NULL DEFAULT 0,
  `dcto` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `albaranes`
--

CREATE TABLE `albaranes` (
  `codalbaran` int(11) NOT NULL,
  `codfactura` int(11) NOT NULL DEFAULT 0,
  `fecha` date NOT NULL DEFAULT '0000-00-00',
  `iva` tinyint(4) NOT NULL DEFAULT 0,
  `codcliente` int(5) DEFAULT 0,
  `estado` varchar(1) CHARACTER SET utf8 DEFAULT '1',
  `totalalbaran` float NOT NULL,
  `borrado` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `albaranesp`
--

CREATE TABLE `albaranesp` (
  `codalbaran` varchar(20) NOT NULL DEFAULT '0',
  `codproveedor` int(5) NOT NULL DEFAULT 0,
  `codfactura` varchar(20) DEFAULT NULL,
  `fecha` date NOT NULL DEFAULT '0000-00-00',
  `iva` tinyint(4) NOT NULL DEFAULT 0,
  `estado` varchar(1) DEFAULT '1',
  `totalalbaran` float NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `albaranesp`
--

INSERT INTO `albaranesp` (`codalbaran`, `codproveedor`, `codfactura`, `fecha`, `iva`, `estado`, `totalalbaran`) VALUES
('2', 2, '2000', '2019-04-05', 16, '2', 11600);

-- --------------------------------------------------------

--
-- Table structure for table `albaranesptmp`
--

CREATE TABLE `albaranesptmp` (
  `codalbaran` int(11) NOT NULL,
  `fecha` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Temporal de albaranes de proveedores para controlar acceso s';

-- --------------------------------------------------------

--
-- Table structure for table `albaranestmp`
--

CREATE TABLE `albaranestmp` (
  `codalbaran` int(11) NOT NULL,
  `fecha` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Temporal de albaranes para controlar acceso simultaneo';

-- --------------------------------------------------------

--
-- Table structure for table `articulos`
--

CREATE TABLE `articulos` (
  `codarticulo` int(10) NOT NULL,
  `codfamilia` int(5) NOT NULL,
  `referencia` varchar(20) NOT NULL,
  `descripcion` text NOT NULL,
  `impuesto` float NOT NULL,
  `codproveedor1` int(5) NOT NULL DEFAULT 1,
  `codproveedor2` int(5) NOT NULL,
  `descripcion_corta` varchar(30) NOT NULL,
  `codubicacion` int(3) NOT NULL,
  `stock` int(10) NOT NULL,
  `stock_minimo` int(8) NOT NULL,
  `aviso_minimo` varchar(1) NOT NULL DEFAULT '0',
  `datos_producto` varchar(200) NOT NULL,
  `fecha_alta` date NOT NULL DEFAULT '0000-00-00',
  `codembalaje` int(3) NOT NULL,
  `unidades_caja` int(8) NOT NULL,
  `precio_ticket` varchar(1) NOT NULL DEFAULT '0',
  `modificar_ticket` varchar(1) NOT NULL DEFAULT '0',
  `observaciones` text NOT NULL,
  `precio_compra` float(10,2) DEFAULT NULL,
  `precio_almacen` float(10,2) DEFAULT NULL,
  `precio_tienda` float(10,2) DEFAULT NULL,
  `precio_pvp` float(10,2) DEFAULT NULL,
  `precio_iva` float(10,2) DEFAULT NULL,
  `codigobarras` varchar(15) NOT NULL,
  `imagen` varchar(200) NOT NULL,
  `borrado` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Articulos';

--
-- Dumping data for table `articulos`
--

INSERT INTO `articulos` (`codarticulo`, `codfamilia`, `referencia`, `descripcion`, `impuesto`, `codproveedor1`, `codproveedor2`, `descripcion_corta`, `codubicacion`, `stock`, `stock_minimo`, `aviso_minimo`, `datos_producto`, `fecha_alta`, `codembalaje`, `unidades_caja`, `precio_ticket`, `modificar_ticket`, `observaciones`, `precio_compra`, `precio_almacen`, `precio_tienda`, `precio_pvp`, `precio_iva`, `codigobarras`, `imagen`, `borrado`) VALUES
(1, 1, 'carne picada', '80/20', 7, 7, 1, 'picada para relleno', 1, 1025, 1, '1', 'FINE GROUND BEEF', '2019-02-22', 2, 1, '0', '0', '', 2.06, 0.00, 0.00, NULL, 0.00, '111111111111111', 'foto1.jpg', '0'),
(2, 1, 'Cebolla', 'bolsa de cobolla', 7, 0, 17, 'cebolla x bolsa', 1, 0, 0, '0', '', '2019-03-23', 3, 10, '0', '', '', 0.00, 0.00, 0.00, NULL, 0.00, '', 'foto2.jpg', '0'),
(3, 3, 'empanada de carne', 'Empanada clasica de Carne de vaca 12u.', 7, 18, 0, 'empanadas carne', 1, -2, 0, '0', '', '0000-00-00', 3, 0, '0', '', '', 0.00, 0.00, 10.00, NULL, 10.70, '', 'foto3.jpg', '0'),
(4, 3, 'empanada de pollo', 'Empanada clasica de pollo 12u.', 7, 18, 0, 'empanada pollo', 1, 0, 0, '0', '', '0000-00-00', 3, 0, '0', '', '', 0.00, 0.00, 8.00, NULL, 8.60, '', 'foto4.jpg', '0'),
(5, 3, 'Pizza de queso', 'Pizza 8 porciones de queso mozzarella', 7, 18, 0, 'pizzaQ', 1, -5, 0, '0', '', '2019-03-23', 3, 1, '0', '', '', 0.00, 0.00, 5.00, NULL, 5.35, '', 'foto5.jpg', '0');

-- --------------------------------------------------------

--
-- Table structure for table `artpro`
--

CREATE TABLE `artpro` (
  `codarticulo` varchar(15) NOT NULL,
  `codfamilia` int(3) NOT NULL,
  `codproveedor` int(5) NOT NULL,
  `precio` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `artpro`
--

INSERT INTO `artpro` (`codarticulo`, `codfamilia`, `codproveedor`, `precio`) VALUES
('1', 1, 3, 10),
('1', 1, 1, 10),
('1', 1, 2, 10);

-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

CREATE TABLE `batch` (
  `codbatch` int(5) NOT NULL,
  `descripcion` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `cantidad` int(8) NOT NULL,
  `fechai` date NOT NULL,
  `horai` varchar(5) COLLATE latin1_spanish_ci NOT NULL,
  `fechaf` date NOT NULL,
  `horaf` varchar(5) COLLATE latin1_spanish_ci NOT NULL,
  `estado` varchar(1) COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clientes`
--

CREATE TABLE `clientes` (
  `codcliente` int(5) NOT NULL,
  `Pais` varchar(20) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `nif` varchar(12) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `codprovincia` int(2) NOT NULL DEFAULT 0,
  `localidad` varchar(35) NOT NULL,
  `codformapago` int(2) NOT NULL DEFAULT 0,
  `codentidad` int(2) NOT NULL DEFAULT 0,
  `cuentabancaria` varchar(20) NOT NULL,
  `codpostal` varchar(5) NOT NULL,
  `telefono` varchar(14) NOT NULL,
  `movil` varchar(14) NOT NULL,
  `email` varchar(35) NOT NULL,
  `web` varchar(45) NOT NULL,
  `borrado` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Clientes';

--
-- Dumping data for table `clientes`
--

INSERT INTO `clientes` (`codcliente`, `Pais`, `nombre`, `nif`, `direccion`, `codprovincia`, `localidad`, `codformapago`, `codentidad`, `cuentabancaria`, `codpostal`, `telefono`, `movil`, `email`, `web`, `borrado`) VALUES
(3, '', 'Giuseppe Piazza', '555555555', 'Green Palm Driv. 54', 61, 'Miami Vice', 0, 0, '', '54/13', '80046804', '', 'giuseppepizza@pizzaline.com', '', '0'),
(2, '', 'empanandas pampa', '444444444', 'sunny beach 54', 61, 'miami', 0, 0, '', '', '', '', '', '', '0'),
(1, '', 'Consumidor Final', '', '', 0, '', 0, 0, '', '', '', '', '', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `cobros`
--

CREATE TABLE `cobros` (
  `id` int(11) NOT NULL,
  `codfactura` int(11) NOT NULL,
  `codcliente` int(5) NOT NULL,
  `importe` float NOT NULL,
  `codformapago` int(2) NOT NULL,
  `numdocumento` varchar(30) NOT NULL,
  `fechacobro` date NOT NULL DEFAULT '0000-00-00',
  `observaciones` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Cobros de facturas a clientes';

--
-- Dumping data for table `cobros`
--

INSERT INTO `cobros` (`id`, `codfactura`, `codcliente`, `importe`, `codformapago`, `numdocumento`, `fechacobro`, `observaciones`) VALUES
(1, 5, 2, 75.4, 1, '', '2019-03-03', ''),
(2, 7, 2, 469.8, 1, '', '2019-04-05', '');

-- --------------------------------------------------------

--
-- Table structure for table `embalajes`
--

CREATE TABLE `embalajes` (
  `codembalaje` int(3) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  `borrado` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Embalajes';

--
-- Dumping data for table `embalajes`
--

INSERT INTO `embalajes` (`codembalaje`, `nombre`, `borrado`) VALUES
(1, 'cajon de 5kg', '1'),
(2, 'GROUND beef 80 LB CASE', '0'),
(3, 'bolsa 50 lb', '0'),
(4, 'caja 25 lb', '0'),
(5, '10 kg bag', '0');

-- --------------------------------------------------------

--
-- Table structure for table `entidades`
--

CREATE TABLE `entidades` (
  `codentidad` int(2) NOT NULL,
  `nombreentidad` varchar(50) NOT NULL,
  `borrado` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Entidades Bancarias';

-- --------------------------------------------------------

--
-- Table structure for table `estaciones`
--

CREATE TABLE `estaciones` (
  `codestacion` int(5) NOT NULL,
  `nombre` varchar(35) COLLATE latin1_spanish_ci NOT NULL,
  `borrado` varchar(1) COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Dumping data for table `estaciones`
--

INSERT INTO `estaciones` (`codestacion`, `nombre`, `borrado`) VALUES
(1, 'laminadora', '0'),
(2, 'cortadora de discos', '0'),
(3, 'Mezcladora', '0'),
(4, 'conformadora', '0'),
(5, 'Zobadora', '0'),
(6, 'zona de empaque', '0'),
(7, 'cierre al vacio ', '0'),
(8, 'Cortado', '0'),
(9, 'Cocina', '0'),
(10, 'Horno', '0'),
(11, 'laboratorio gourmet', '0'),
(12, 'mount engine desk', '0');

-- --------------------------------------------------------

--
-- Table structure for table `estado`
--

CREATE TABLE `estado` (
  `codestado` int(1) NOT NULL,
  `estado` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `estado`
--

INSERT INTO `estado` (`codestado`, `estado`) VALUES
(0, 'inicializado'),
(1, 'finalizado'),
(2, 'descartado');

-- --------------------------------------------------------

--
-- Table structure for table `factulinea`
--

CREATE TABLE `factulinea` (
  `codfactura` int(11) NOT NULL,
  `numlinea` int(4) NOT NULL,
  `codfamilia` int(3) NOT NULL,
  `codigo` varchar(15) NOT NULL,
  `cantidad` float NOT NULL,
  `precio` float NOT NULL,
  `importe` float NOT NULL,
  `dcto` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='lineas de facturas a clientes';

--
-- Dumping data for table `factulinea`
--

INSERT INTO `factulinea` (`codfactura`, `numlinea`, `codfamilia`, `codigo`, `cantidad`, `precio`, `importe`, `dcto`) VALUES
(0, 1, 1, '1', 1, 10, 10, 0),
(2, 1, 1, '1', 1, 10, 10, 0),
(2, 2, 1, '1', 1, 100, 100, 0),
(3, 1, 1, '1', 1, 10, 10, 0),
(3, 2, 1, '1', 1, 100, 100, 0),
(3, 3, 1, '1', 1, 50, 50, 0),
(3, 4, 1, '1', 1, 70, 70, 0),
(4, 1, 1, '1', 1, 120, 120, 0),
(5, 1, 1, '1', 1, 65, 65, 0),
(6, 1, 0, '', 1, 10, 10, 0),
(7, 1, 3, '3', 2, 100, 180, 10),
(7, 2, 3, '5', 5, 50, 225, 10);

-- --------------------------------------------------------

--
-- Table structure for table `factulineap`
--

CREATE TABLE `factulineap` (
  `codfactura` varchar(20) NOT NULL DEFAULT '',
  `codproveedor` int(5) NOT NULL,
  `numlinea` int(4) NOT NULL,
  `codfamilia` int(3) NOT NULL,
  `codigo` varchar(15) NOT NULL,
  `cantidad` float NOT NULL,
  `precio` float NOT NULL,
  `importe` float NOT NULL,
  `dcto` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='lineas de facturas de proveedores';

--
-- Dumping data for table `factulineap`
--

INSERT INTO `factulineap` (`codfactura`, `codproveedor`, `numlinea`, `codfamilia`, `codigo`, `cantidad`, `precio`, `importe`, `dcto`) VALUES
('58444990421', 3, 1, 1, '1', 1, 10, 10, 0),
('65469849874', 1, 1, 1, '1', 1, 10, 10, 0),
('65469849874', 1, 2, 1, '1', 1, 10, 10, 0),
('757864564', 3, 1, 1, '1', 1, 10, 10, 0),
('757864564', 3, 2, 1, '1', 1, 10, 10, 0),
('757864564', 3, 3, 1, '1', 10, 10, 100, 0),
('65465456465', 3, 1, 1, '1', 1, 10, 10, 0),
('65465456465', 3, 2, 1, '1', 1, 10, 10, 0),
('65465456465', 3, 3, 1, '1', 10, 10, 100, 0),
('65465456465', 3, 4, 1, '1', 1, 10, 10, 0),
('9946512312312', 2, 1, 1, '1', 1, 10, 10, 0),
('2000', 2, 1, 1, '1', 1000, 10, 10000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `factulineaptmp`
--

CREATE TABLE `factulineaptmp` (
  `codfactura` int(11) NOT NULL,
  `numlinea` int(4) NOT NULL,
  `codfamilia` int(3) NOT NULL,
  `codigo` varchar(15) NOT NULL,
  `cantidad` float NOT NULL,
  `precio` float NOT NULL,
  `importe` float NOT NULL,
  `dcto` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='lineas de facturas de proveedores temporal';

--
-- Dumping data for table `factulineaptmp`
--

INSERT INTO `factulineaptmp` (`codfactura`, `numlinea`, `codfamilia`, `codigo`, `cantidad`, `precio`, `importe`, `dcto`) VALUES
(0, 1, 1, '1', 1, 10, 10, 0),
(0, 2, 1, '1', 1, 10, 10, 0),
(0, 3, 1, '1', 10, 10, 100, 0),
(0, 4, 1, '1', 1, 10, 10, 0);

-- --------------------------------------------------------

--
-- Table structure for table `factulineatmp`
--

CREATE TABLE `factulineatmp` (
  `codfactura` int(11) NOT NULL,
  `numlinea` int(4) NOT NULL,
  `codfamilia` int(3) NOT NULL,
  `codigo` varchar(15) NOT NULL,
  `cantidad` float NOT NULL,
  `precio` float NOT NULL,
  `importe` float NOT NULL,
  `dcto` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Temporal de linea de facturas a clientes';

--
-- Dumping data for table `factulineatmp`
--

INSERT INTO `factulineatmp` (`codfactura`, `numlinea`, `codfamilia`, `codigo`, `cantidad`, `precio`, `importe`, `dcto`) VALUES
(0, 1, 1, '1', 1, 10, 10, 0),
(0, 2, 1, '1', 1, 100, 100, 0),
(0, 3, 1, '1', 1, 50, 50, 0),
(0, 4, 1, '1', 1, 70, 70, 0),
(0, 5, 1, '1', 1, 80, 80, 0);

-- --------------------------------------------------------

--
-- Table structure for table `facturas`
--

CREATE TABLE `facturas` (
  `codfactura` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `iva` tinyint(4) NOT NULL,
  `codcliente` int(5) NOT NULL,
  `estado` varchar(1) NOT NULL DEFAULT '0',
  `totalfactura` float NOT NULL,
  `fechavencimiento` date NOT NULL DEFAULT '0000-00-00',
  `borrado` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='facturas de ventas a clientes';

--
-- Dumping data for table `facturas`
--

INSERT INTO `facturas` (`codfactura`, `fecha`, `iva`, `codcliente`, `estado`, `totalfactura`, `fechavencimiento`, `borrado`) VALUES
(1, '2019-03-02', 16, 1, '1', 0, '0000-00-00', '0'),
(2, '2019-03-02', 16, 1, '1', 127.6, '0000-00-00', '0'),
(3, '2019-03-02', 16, 1, '1', 266.8, '0000-00-00', '0'),
(4, '2019-03-02', 16, 1, '1', 139.2, '0000-00-00', '0'),
(5, '2019-03-03', 16, 2, '1', 75.4, '0000-00-00', '0'),
(6, '2019-04-05', 16, 1, '1', 11.6, '0000-00-00', '0'),
(7, '2019-04-05', 16, 2, '2', 469.8, '0000-00-00', '0');

-- --------------------------------------------------------

--
-- Table structure for table `facturasp`
--

CREATE TABLE `facturasp` (
  `codfactura` varchar(20) NOT NULL DEFAULT '',
  `codproveedor` int(5) NOT NULL,
  `fecha` date NOT NULL,
  `iva` tinyint(4) NOT NULL,
  `estado` varchar(1) NOT NULL DEFAULT '0',
  `totalfactura` float NOT NULL,
  `fechapago` date NOT NULL DEFAULT '0000-00-00',
  `borrado` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='facturas de compras a proveedores';

--
-- Dumping data for table `facturasp`
--

INSERT INTO `facturasp` (`codfactura`, `codproveedor`, `fecha`, `iva`, `estado`, `totalfactura`, `fechapago`, `borrado`) VALUES
('58444990421', 3, '2019-02-22', 7, '1', 10.7, '0000-00-00', '0'),
('65469849874', 1, '2019-02-22', 16, '1', 23.2, '0000-00-00', '0'),
('757864564', 3, '2019-02-26', 7, '1', 128.4, '0000-00-00', '0'),
('65465456465', 3, '2019-02-26', 16, '1', 150.8, '0000-00-00', '0'),
('9946512312312', 2, '2019-02-26', 7, '2', 10.7, '0000-00-00', '0'),
('2000', 2, '2019-04-05', 16, '2', 11600, '0000-00-00', '0');

-- --------------------------------------------------------

--
-- Table structure for table `facturasptmp`
--

CREATE TABLE `facturasptmp` (
  `codfactura` int(11) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='temporal de facturas de proveedores';

-- --------------------------------------------------------

--
-- Table structure for table `facturastmp`
--

CREATE TABLE `facturastmp` (
  `codfactura` int(11) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='temporal de facturas a clientes';

-- --------------------------------------------------------

--
-- Table structure for table `familias`
--

CREATE TABLE `familias` (
  `codfamilia` int(5) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `borrado` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='familia de articulos';

--
-- Dumping data for table `familias`
--

INSERT INTO `familias` (`codfamilia`, `nombre`, `borrado`) VALUES
(1, 'Materias Primas', '0'),
(2, 'Producto Intermedio', '0'),
(3, 'Producto Terminado', '0');

-- --------------------------------------------------------

--
-- Table structure for table `formapago`
--

CREATE TABLE `formapago` (
  `codformapago` int(2) NOT NULL,
  `nombrefp` varchar(40) NOT NULL,
  `borrado` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Forma de pago';

--
-- Dumping data for table `formapago`
--

INSERT INTO `formapago` (`codformapago`, `nombrefp`, `borrado`) VALUES
(1, 'Efectivo', '0'),
(2, 'tarjeta', '0'),
(3, 'transferencia bcaria', '0'),
(4, 'cheques', '0'),
(5, 'Bitcoins', '1');

-- --------------------------------------------------------

--
-- Table structure for table `impuestos`
--

CREATE TABLE `impuestos` (
  `codimpuesto` int(3) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `valor` float NOT NULL,
  `borrado` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='tipos de impuestos';

--
-- Dumping data for table `impuestos`
--

INSERT INTO `impuestos` (`codimpuesto`, `nombre`, `valor`, `borrado`) VALUES
(1, 'tax', 7, '0');

-- --------------------------------------------------------

--
-- Table structure for table `librodiario`
--

CREATE TABLE `librodiario` (
  `id` int(8) NOT NULL,
  `fecha` date NOT NULL DEFAULT '0000-00-00',
  `tipodocumento` varchar(1) NOT NULL,
  `coddocumento` varchar(20) NOT NULL,
  `codcomercial` int(5) NOT NULL,
  `codformapago` int(2) NOT NULL,
  `numpago` varchar(30) NOT NULL,
  `total` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Movimientos diarios';

--
-- Dumping data for table `librodiario`
--

INSERT INTO `librodiario` (`id`, `fecha`, `tipodocumento`, `coddocumento`, `codcomercial`, `codformapago`, `numpago`, `total`) VALUES
(1, '2019-03-03', '2', '5', 2, 1, '', 75.4),
(2, '2019-03-09', '1', '9946512312312', 2, 4, '', 10.7),
(3, '2019-04-05', '2', '7', 2, 1, '', 469.8),
(4, '2019-04-05', '1', '2000', 2, 1, '', 11600);

-- --------------------------------------------------------

--
-- Table structure for table `lote`
--

CREATE TABLE `lote` (
  `codlote` int(5) NOT NULL,
  `codarticulo` int(5) NOT NULL,
  `cantidad` int(8) DEFAULT NULL,
  `fechai` date NOT NULL,
  `horai` varchar(8) COLLATE latin1_spanish_ci NOT NULL,
  `fechaf` date DEFAULT NULL,
  `horaf` varchar(8) COLLATE latin1_spanish_ci DEFAULT NULL,
  `codstatus` int(1) NOT NULL,
  `borrado` varchar(1) COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Dumping data for table `lote`
--

INSERT INTO `lote` (`codlote`, `codarticulo`, `cantidad`, `fechai`, `horai`, `fechaf`, `horaf`, `codstatus`, `borrado`) VALUES
(0, 0, 0, '0000-00-00', '', '0000-00-00', '', 0, '1'),
(1, 1, 50, '2019-03-17', '12:00', '0000-00-00', '', 0, '0'),
(2, 1, 10, '2019-03-10', '11:00', '2019-04-12', '18:00', 1, '0'),
(3, 3, 0, '2019-03-26', '21:29', '0000-00-00', '', 0, '0'),
(4, 4, 30, '2019-03-26', '21:32', '0000-00-00', '', 0, '0'),
(5, 5, 100, '2019-03-26', '22:13', '0000-00-00', '', 2, '0'),
(6, 3, 90, '2019-03-26', '22:13', '0000-00-00', '', 0, '0'),
(7, 5, 5, '2019-03-26', '22:18', '0000-00-00', '', 0, '0'),
(8, 3, 0, '2019-04-05', '12:23', '0000-00-00', '', 0, '0'),
(9, 3, 50, '2019-04-05', '21:48', '0000-00-00', '', 0, '0'),
(10, 4, 100, '2019-04-25', '15:11', '0000-00-00', '', 0, '0'),
(11, 5, 150, '2019-04-26', '10:59:01', NULL, NULL, 0, '0');

-- --------------------------------------------------------

--
-- Table structure for table `lotelinea`
--

CREATE TABLE `lotelinea` (
  `codlotelinea` int(5) NOT NULL,
  `codlote` int(5) NOT NULL,
  `codproceso` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pagos`
--

CREATE TABLE `pagos` (
  `id` int(11) NOT NULL,
  `codfactura` varchar(20) NOT NULL,
  `codproveedor` int(5) NOT NULL,
  `importe` float NOT NULL,
  `codformapago` int(2) NOT NULL,
  `numdocumento` varchar(30) NOT NULL,
  `fechapago` date DEFAULT '0000-00-00',
  `observaciones` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Pagos de facturas a proveedores';

--
-- Dumping data for table `pagos`
--

INSERT INTO `pagos` (`id`, `codfactura`, `codproveedor`, `importe`, `codformapago`, `numdocumento`, `fechapago`, `observaciones`) VALUES
(1, '9946512312312', 2, 10.7, 4, '', '2019-03-09', ''),
(2, '2000', 2, 11600, 1, '', '2019-04-05', '');

-- --------------------------------------------------------

--
-- Table structure for table `pais`
--

CREATE TABLE `pais` (
  `codPais` int(5) NOT NULL,
  `lengua` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `nombrePais` varchar(40) COLLATE latin1_spanish_ci NOT NULL,
  `borrado` varchar(1) COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Dumping data for table `pais`
--

INSERT INTO `pais` (`codPais`, `lengua`, `nombrePais`, `borrado`) VALUES
(1, 'Espanol', 'Argentina', '0'),
(2, 'Espanol', 'Espana', '0'),
(3, 'English', 'United States of America', '0');

-- --------------------------------------------------------

--
-- Table structure for table `procesos`
--

CREATE TABLE `procesos` (
  `codproceso` int(5) NOT NULL,
  `nombre` int(35) NOT NULL,
  `fechai` date NOT NULL,
  `horai` varchar(5) COLLATE latin1_spanish_ci NOT NULL,
  `horaf` varchar(5) COLLATE latin1_spanish_ci NOT NULL,
  `fechaf` date NOT NULL,
  `codestacion` int(5) NOT NULL,
  `codtrabajador` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `procesostmp`
--

CREATE TABLE `procesostmp` (
  `codproceso` int(5) NOT NULL,
  `fechai` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `proveedores`
--

CREATE TABLE `proveedores` (
  `codproveedor` int(5) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `nif` varchar(12) NOT NULL,
  `codpais` int(3) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `codprovincia` int(2) NOT NULL,
  `localidad` varchar(35) NOT NULL,
  `codentidad` int(2) NOT NULL,
  `cuentabancaria` varchar(20) NOT NULL,
  `codpostal` varchar(5) NOT NULL,
  `telefono` varchar(14) NOT NULL,
  `movil` varchar(14) NOT NULL,
  `email` varchar(35) NOT NULL,
  `web` varchar(45) NOT NULL,
  `borrado` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Proveedores';

--
-- Dumping data for table `proveedores`
--

INSERT INTO `proveedores` (`codproveedor`, `nombre`, `nif`, `codpais`, `direccion`, `codprovincia`, `localidad`, `codentidad`, `cuentabancaria`, `codpostal`, `telefono`, `movil`, `email`, `web`, `borrado`) VALUES
(1, 'GORDON FOOD ', '', 0, 'Miami Distribution Ctr ', 0, 'Miami', 0, '', '33167', '800-830-9767', '954-895-4997', 'jarrett.sammel@gfs.com', '', '0'),
(2, 'Tapam llc', '', 0, '71st Street', 0, 'miami', 0, '', '33166', '', '', '', '', '0'),
(3, 'SOUTH FLORIDA TRAINING CORP.', '', 0, '13 street', 0, 'miami', 0, '', '33172', '3059947817', '', '', '', '0'),
(4, 'SYSCO', '', 0, '12500 sysco way', 0, 'medley', 0, '', '33178', '305-651-5421', '305-926-3189', 'dicembrino.alesandro@sfl.sysco.com', '', '0'),
(5, 'RESTAURANT DEPOT', '', 0, '3500 davie rd', 0, '', 0, '', '33314', '', '', '', 'www.restaurantdepot.com', '0'),
(6, 'tama corp.', '', 0, '7921 nw 21st st', 0, 'doral', 0, '', '33122', '305-592-1717', '', '', 'www.elpaisa.net', '0'),
(7, 'DEL ROSARIO DISTRIBUTION', '', 0, '7341 nw 79th terrace', 0, 'medley', 0, '', '33166', '305-592-0050', '', 'info@delrosariodistribution.com', '', '0'),
(8, 'BOLUFE SERVICES & SALES', '', 0, '', 0, '', 0, '', '', '954-513-8440', '305-746-7162', '', '', '0'),
(9, 'BEITAR FRESH PRODUCTS', '', 0, '', 0, '', 0, '', '', '7886-306-0048', '', '', '', '0'),
(10, 'PDP GROUP', '', 0, '8040NW 71ST', 0, 'MIAMI', 0, '', '33166', '786-357-8261', '786-331-7500', '', '', '0'),
(11, 'ALIMENTOS AUSTRALES', '', 0, '13049 SW 122ND AVE', 0, 'MIAMI', 0, '', '', '305-238-7755', '', '', '', '0'),
(12, 'INTERMARK FOODS, INC', '', 0, '1355 NW 97 AVE', 0, 'DORAL', 0, '', '33172', '305-718-8754', '', '', '', '0'),
(13, 'SIGNATURE SEASONING', '', 0, 'POBOX 56438', 0, 'VIRGINIA BEACH', 0, '', '23456', '757-572-8995', '', 'SUSAN@SIGNATURESEASONINGS.COM', '', '0'),
(14, 'ORSO', '', 0, '8420 NW 61ST STREET', 0, 'MIAMI', 0, '', '33166', '', '', '', '', '0'),
(15, 'CHEF MERITO, INC', '', 0, '7915 SEPULVEDA BLVD', 0, 'VAN NUYS', 0, '', '91405', '818-787-0100', '', '', 'WWW.CHEFMERITO.COM', '0'),
(16, 'MEDINA BAKING & POWDER PRODUCTS', '', 0, '1864 NW 22ND ST', 0, 'MIAMI', 0, '', '33142', '305-545-5436', '305-545-5437', 'SALES@MEDINABAKING.COM', 'WWW.MEDINABAKING.COM', '0'),
(17, 'ABC BAKERY SUPPLIES & EQUIP', '', 0, '7200 NW 1ST AVE', 0, 'MIAMI', 0, '', '33150', '305-757-3885', '', '', '', '0'),
(18, 'Produccion propia', '', 0, '', 0, '', 0, '', '', '', '', '', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `provincias`
--

CREATE TABLE `provincias` (
  `codprovincia` int(2) NOT NULL,
  `codpais` int(3) NOT NULL,
  `stateCode` varchar(4) NOT NULL,
  `nombreprovincia` varchar(40) NOT NULL,
  `region` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Provincias';

--
-- Dumping data for table `provincias`
--

INSERT INTO `provincias` (`codprovincia`, `codpais`, `stateCode`, `nombreprovincia`, `region`) VALUES
(1, 2, '', 'Alava', ''),
(2, 2, '', 'Albacete', ''),
(3, 2, '', 'Alicante', ''),
(4, 2, '', 'Almeria', ''),
(5, 2, '', 'Asturias', ''),
(6, 2, '', 'Avila', ''),
(7, 2, '', 'Badajoz', ''),
(8, 2, '', 'Baleares', ''),
(9, 2, '', 'Barcelona', ''),
(10, 2, '', 'Burgos', ''),
(11, 2, '', 'Caceres', ''),
(12, 2, '', 'Cadiz', ''),
(13, 2, '', 'Cantabria', ''),
(14, 2, '', 'Castellon', ''),
(15, 2, '', 'Ceuta', ''),
(16, 2, '', 'Ciudad Real', ''),
(17, 2, '', 'Cordoba', ''),
(18, 2, '', 'La Coru?a', ''),
(19, 2, '', 'Cuenca', ''),
(20, 2, '', 'Gerona', ''),
(21, 2, '', 'Granada', ''),
(22, 2, '', 'Guadalajara', ''),
(23, 2, '', 'Guipuzcoa', ''),
(24, 2, '', 'Huelva', ''),
(25, 2, '', 'Huesca', ''),
(26, 2, '', 'Jaen', ''),
(27, 2, '', 'Leon', ''),
(28, 2, '', 'Lerida', ''),
(29, 2, '', 'Lugo', ''),
(30, 2, '', 'Madrid', ''),
(31, 2, '', 'Malaga', ''),
(32, 2, '', 'Melilla', ''),
(33, 2, '', 'Murcia', ''),
(34, 2, '', 'Navarra', ''),
(35, 2, '', 'Orense', ''),
(36, 2, '', 'Palencia', ''),
(37, 2, '', 'Las Palmas', ''),
(38, 2, '', 'Pontevedra', ''),
(39, 2, '', 'La Rioja', ''),
(40, 2, '', 'Salamanca', ''),
(41, 2, '', 'Sta. Cruz de Tenerife', ''),
(42, 2, '', 'Segovia', ''),
(43, 2, '', 'Sevilla', ''),
(44, 2, '', 'Soria', ''),
(45, 2, '', 'Tarragona', ''),
(46, 2, '', 'Teruel', ''),
(47, 2, '', 'Toledo', ''),
(48, 2, '', 'Valencia', ''),
(49, 2, '', 'Valladolid', ''),
(50, 2, '', 'Vizcaya', ''),
(51, 2, '', 'Zamora', ''),
(52, 2, '', 'Zaragoza', ''),
(53, 3, 'AK', 'Alaska', ''),
(54, 3, 'AZ', 'Arizona', ''),
(55, 3, 'AR', 'Arkansas', ''),
(56, 3, 'CA', 'California', ''),
(57, 3, 'CO', 'Colorado', ''),
(58, 3, 'CT', 'Connecticut', ''),
(59, 3, 'DE', 'Delaware', ''),
(60, 3, 'DC', 'District of Columbia', ''),
(61, 3, 'FL', 'Florida', ''),
(62, 3, 'GA', 'Georgia', ''),
(63, 3, 'HI', 'Hawaii', ''),
(64, 3, 'ID', 'Idaho', ''),
(65, 3, 'IL', 'Illinois', ''),
(66, 3, 'IN', 'Indiana', ''),
(67, 3, 'IA', 'Iowa', ''),
(68, 3, 'KS', 'Kansas', ''),
(69, 3, 'KY', 'Kentucky', ''),
(70, 3, 'LA', 'Louisiana', ''),
(71, 3, 'ME', 'Maine', ''),
(72, 3, 'MD', 'Maryland', ''),
(73, 3, 'MA', 'Massachusetts', ''),
(74, 3, 'MI', 'Michigan', ''),
(75, 3, 'MN', 'Minnesota', ''),
(76, 3, 'MS', 'Mississippi', ''),
(77, 3, 'MO', 'Missouri', ''),
(78, 3, 'MT', 'Montana', ''),
(79, 3, 'NE', 'Nebraska', ''),
(80, 3, 'NV', 'Nevada', ''),
(81, 3, 'NH', 'New Hampshire', ''),
(82, 3, 'NJ', 'New Jersey', ''),
(83, 3, 'NM', 'New Mexico', ''),
(84, 3, 'NY', 'New York', ''),
(85, 3, 'NC', 'North Carolina', ''),
(86, 3, 'ND', 'North Dakota', ''),
(87, 3, 'OH', 'Ohio', ''),
(88, 3, 'OK', 'Oklahoma', ''),
(89, 3, 'OR', 'Oregon', ''),
(90, 3, 'PA', 'Pennsylvania', ''),
(91, 3, 'PR', 'Puerto Rico', ''),
(92, 3, 'RI', 'Rhode Island', ''),
(93, 3, 'SC', 'South Carolina', ''),
(94, 3, 'SD', 'South Dakota', ''),
(95, 3, 'TN', 'Tennessee', ''),
(96, 3, 'TX', 'Texas', ''),
(97, 3, 'UT', 'Utah', ''),
(98, 3, 'VT', 'Vermont', ''),
(99, 3, 'VA', 'Virginia', ''),
(100, 3, 'WA', 'Washington', ''),
(101, 3, 'WV', 'West Virginia', ''),
(102, 3, 'WI', 'Wisconsin', ''),
(103, 3, 'WY', 'Wyoming', ''),
(104, 3, 'AL', 'Alabama', ''),
(105, 1, 'BA', 'Buenos Aires', ''),
(106, 1, 'GBA', 'Buenos Aires-GBA', ''),
(107, 1, 'CABA', 'Capital Federal', ''),
(108, 1, 'CTMC', 'Catamarca', ''),
(109, 1, 'CHCO', 'Chaco', ''),
(110, 1, 'CHBT', 'Chubut', ''),
(111, 1, 'CDBA', 'Córdoba', ''),
(112, 1, 'CRT', 'Corrientes', ''),
(113, 1, 'ENR', 'Entre Ríos', ''),
(114, 1, 'FRZ', 'Formosa', ''),
(115, 1, 'JJY', 'Jujuy', ''),
(116, 1, 'LP', 'La Pampa', ''),
(117, 1, 'LRJ', 'La Rioja', ''),
(118, 1, 'MDZ', 'Mendoza', ''),
(119, 1, 'MSN', 'Misiones', ''),
(120, 1, 'NQN', 'Neuquén', ''),
(121, 1, 'RNGR', 'Río Negro', ''),
(122, 1, 'SAL', 'Salta', ''),
(123, 1, 'SNJN', 'San Juan', ''),
(124, 1, 'SNLS', 'San Luis', ''),
(125, 1, 'STCZ', 'Santa Cruz', ''),
(126, 1, 'STFE', 'Santa Fe', ''),
(127, 1, 'SDE', 'Santiago del Estero', ''),
(128, 1, 'TDF', 'Tierra del Fuego', ''),
(129, 1, 'TUCU', 'Tucumán', '');

-- --------------------------------------------------------

--
-- Table structure for table `tabbackup`
--

CREATE TABLE `tabbackup` (
  `id` int(6) NOT NULL,
  `denominacion` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `archivo` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `trabajadores`
--

CREATE TABLE `trabajadores` (
  `codtrabajador` int(5) NOT NULL,
  `nombre` varchar(45) COLLATE latin1_spanish_ci NOT NULL,
  `nif` varchar(12) COLLATE latin1_spanish_ci NOT NULL,
  `password` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `telefono` varchar(14) COLLATE latin1_spanish_ci NOT NULL,
  `movil` varchar(14) COLLATE latin1_spanish_ci NOT NULL,
  `movilavisos` varchar(35) COLLATE latin1_spanish_ci NOT NULL,
  `email` varchar(35) COLLATE latin1_spanish_ci NOT NULL,
  `emailavisos` varchar(35) COLLATE latin1_spanish_ci NOT NULL,
  `borrado` varchar(1) COLLATE latin1_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Dumping data for table `trabajadores`
--

INSERT INTO `trabajadores` (`codtrabajador`, `nombre`, `nif`, `password`, `telefono`, `movil`, `movilavisos`, `email`, `emailavisos`, `borrado`) VALUES
(1, 'Martin Drot', '999999', '12345678', '727561525', '556465465', '646545665', 'mdgourville@gmail.com', 'mdgourville2@gmail.com', '0'),
(6, 'MIlosz jedrecki', '', '', '', '', '', '', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `ubicaciones`
--

CREATE TABLE `ubicaciones` (
  `codubicacion` int(3) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `borrado` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Ubicaciones';

--
-- Dumping data for table `ubicaciones`
--

INSERT INTO `ubicaciones` (`codubicacion`, `nombre`, `borrado`) VALUES
(1, 'Sede principal Miami', '0'),
(2, 'wroclaw', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `albalinea`
--
ALTER TABLE `albalinea`
  ADD PRIMARY KEY (`codalbaran`,`numlinea`);

--
-- Indexes for table `albalineap`
--
ALTER TABLE `albalineap`
  ADD PRIMARY KEY (`codalbaran`,`codproveedor`,`numlinea`);

--
-- Indexes for table `albalineaptmp`
--
ALTER TABLE `albalineaptmp`
  ADD PRIMARY KEY (`codalbaran`,`numlinea`);

--
-- Indexes for table `albalineatmp`
--
ALTER TABLE `albalineatmp`
  ADD PRIMARY KEY (`codalbaran`,`numlinea`);

--
-- Indexes for table `albaranes`
--
ALTER TABLE `albaranes`
  ADD PRIMARY KEY (`codalbaran`);

--
-- Indexes for table `albaranesp`
--
ALTER TABLE `albaranesp`
  ADD PRIMARY KEY (`codalbaran`,`codproveedor`);

--
-- Indexes for table `albaranesptmp`
--
ALTER TABLE `albaranesptmp`
  ADD PRIMARY KEY (`codalbaran`);

--
-- Indexes for table `albaranestmp`
--
ALTER TABLE `albaranestmp`
  ADD PRIMARY KEY (`codalbaran`);

--
-- Indexes for table `articulos`
--
ALTER TABLE `articulos`
  ADD PRIMARY KEY (`codarticulo`);

--
-- Indexes for table `artpro`
--
ALTER TABLE `artpro`
  ADD PRIMARY KEY (`codarticulo`,`codfamilia`,`codproveedor`);

--
-- Indexes for table `batch`
--
ALTER TABLE `batch`
  ADD PRIMARY KEY (`codbatch`);

--
-- Indexes for table `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`codcliente`);

--
-- Indexes for table `cobros`
--
ALTER TABLE `cobros`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `embalajes`
--
ALTER TABLE `embalajes`
  ADD PRIMARY KEY (`codembalaje`);

--
-- Indexes for table `entidades`
--
ALTER TABLE `entidades`
  ADD PRIMARY KEY (`codentidad`);

--
-- Indexes for table `estaciones`
--
ALTER TABLE `estaciones`
  ADD PRIMARY KEY (`codestacion`);

--
-- Indexes for table `estado`
--
ALTER TABLE `estado`
  ADD PRIMARY KEY (`codestado`);

--
-- Indexes for table `factulinea`
--
ALTER TABLE `factulinea`
  ADD PRIMARY KEY (`codfactura`,`numlinea`);

--
-- Indexes for table `factulineap`
--
ALTER TABLE `factulineap`
  ADD PRIMARY KEY (`codfactura`,`codproveedor`,`numlinea`);

--
-- Indexes for table `factulineaptmp`
--
ALTER TABLE `factulineaptmp`
  ADD PRIMARY KEY (`codfactura`,`numlinea`);

--
-- Indexes for table `factulineatmp`
--
ALTER TABLE `factulineatmp`
  ADD PRIMARY KEY (`codfactura`,`numlinea`);

--
-- Indexes for table `facturas`
--
ALTER TABLE `facturas`
  ADD PRIMARY KEY (`codfactura`);

--
-- Indexes for table `facturasp`
--
ALTER TABLE `facturasp`
  ADD PRIMARY KEY (`codfactura`,`codproveedor`);

--
-- Indexes for table `facturasptmp`
--
ALTER TABLE `facturasptmp`
  ADD PRIMARY KEY (`codfactura`);

--
-- Indexes for table `facturastmp`
--
ALTER TABLE `facturastmp`
  ADD PRIMARY KEY (`codfactura`);

--
-- Indexes for table `familias`
--
ALTER TABLE `familias`
  ADD PRIMARY KEY (`codfamilia`);

--
-- Indexes for table `formapago`
--
ALTER TABLE `formapago`
  ADD PRIMARY KEY (`codformapago`);

--
-- Indexes for table `impuestos`
--
ALTER TABLE `impuestos`
  ADD PRIMARY KEY (`codimpuesto`);

--
-- Indexes for table `librodiario`
--
ALTER TABLE `librodiario`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lote`
--
ALTER TABLE `lote`
  ADD PRIMARY KEY (`codlote`);

--
-- Indexes for table `lotelinea`
--
ALTER TABLE `lotelinea`
  ADD PRIMARY KEY (`codlotelinea`);

--
-- Indexes for table `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pais`
--
ALTER TABLE `pais`
  ADD PRIMARY KEY (`codPais`);

--
-- Indexes for table `procesos`
--
ALTER TABLE `procesos`
  ADD PRIMARY KEY (`codproceso`);

--
-- Indexes for table `procesostmp`
--
ALTER TABLE `procesostmp`
  ADD PRIMARY KEY (`codproceso`);

--
-- Indexes for table `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`codproveedor`);

--
-- Indexes for table `provincias`
--
ALTER TABLE `provincias`
  ADD PRIMARY KEY (`codprovincia`);

--
-- Indexes for table `tabbackup`
--
ALTER TABLE `tabbackup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trabajadores`
--
ALTER TABLE `trabajadores`
  ADD PRIMARY KEY (`codtrabajador`);

--
-- Indexes for table `ubicaciones`
--
ALTER TABLE `ubicaciones`
  ADD PRIMARY KEY (`codubicacion`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `albalinea`
--
ALTER TABLE `albalinea`
  MODIFY `numlinea` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `albalineap`
--
ALTER TABLE `albalineap`
  MODIFY `numlinea` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `albalineaptmp`
--
ALTER TABLE `albalineaptmp`
  MODIFY `numlinea` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `albalineatmp`
--
ALTER TABLE `albalineatmp`
  MODIFY `numlinea` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `albaranes`
--
ALTER TABLE `albaranes`
  MODIFY `codalbaran` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `albaranesptmp`
--
ALTER TABLE `albaranesptmp`
  MODIFY `codalbaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `albaranestmp`
--
ALTER TABLE `albaranestmp`
  MODIFY `codalbaran` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `articulos`
--
ALTER TABLE `articulos`
  MODIFY `codarticulo` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `batch`
--
ALTER TABLE `batch`
  MODIFY `codbatch` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clientes`
--
ALTER TABLE `clientes`
  MODIFY `codcliente` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cobros`
--
ALTER TABLE `cobros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `embalajes`
--
ALTER TABLE `embalajes`
  MODIFY `codembalaje` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `entidades`
--
ALTER TABLE `entidades`
  MODIFY `codentidad` int(2) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `estaciones`
--
ALTER TABLE `estaciones`
  MODIFY `codestacion` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `estado`
--
ALTER TABLE `estado`
  MODIFY `codestado` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `factulinea`
--
ALTER TABLE `factulinea`
  MODIFY `numlinea` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `factulineap`
--
ALTER TABLE `factulineap`
  MODIFY `numlinea` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `factulineaptmp`
--
ALTER TABLE `factulineaptmp`
  MODIFY `numlinea` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `factulineatmp`
--
ALTER TABLE `factulineatmp`
  MODIFY `numlinea` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `facturas`
--
ALTER TABLE `facturas`
  MODIFY `codfactura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `facturasptmp`
--
ALTER TABLE `facturasptmp`
  MODIFY `codfactura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `facturastmp`
--
ALTER TABLE `facturastmp`
  MODIFY `codfactura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `familias`
--
ALTER TABLE `familias`
  MODIFY `codfamilia` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `formapago`
--
ALTER TABLE `formapago`
  MODIFY `codformapago` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `impuestos`
--
ALTER TABLE `impuestos`
  MODIFY `codimpuesto` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `librodiario`
--
ALTER TABLE `librodiario`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lotelinea`
--
ALTER TABLE `lotelinea`
  MODIFY `codlotelinea` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pagos`
--
ALTER TABLE `pagos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pais`
--
ALTER TABLE `pais`
  MODIFY `codPais` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `procesos`
--
ALTER TABLE `procesos`
  MODIFY `codproceso` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `procesostmp`
--
ALTER TABLE `procesostmp`
  MODIFY `codproceso` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `codproveedor` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `provincias`
--
ALTER TABLE `provincias`
  MODIFY `codprovincia` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT for table `tabbackup`
--
ALTER TABLE `tabbackup`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trabajadores`
--
ALTER TABLE `trabajadores`
  MODIFY `codtrabajador` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ubicaciones`
--
ALTER TABLE `ubicaciones`
  MODIFY `codubicacion` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
